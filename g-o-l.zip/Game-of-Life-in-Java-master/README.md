Game-of-Life-in-Java
====================

Game of Life. Java project inspired by Coderetreat PK. 


# Source code

[GameOfLife](https://github.com/ArturT/Game-of-Life-in-Java/tree/master/src/GameOfLife)

[UnitTests](https://github.com/ArturT/Game-of-Life-in-Java/tree/master/src/UnitTests)


# Example output

											O  O            
											O     OO        
											 O  O    O      
							   OOO  OO        O        O    
							   OOO    O        OOOOOO  O    
							   OOO   OOO        O  O   O    
									O  O         O   O      
									OOOO O OO   OO   O      
									O    OOO    O  OO       
									 OOO         OO         
									  O   O  OO             
					   O            O  O O  OOO             
					 O O           O O O                    
					  OO            OOO                     
									 O                      
															
															
															
															
															
															
	Cells on board: 111
